# [Repositorio en mantenimiento....]

Imgur es un sitio web para alojar imágenes en línea.

Para subir imagenes a su cuenta de Imgur debemos crear una cuenta en: https://imgur.com/signin?redirect=%2F 

Luego, deben registrar una aplicación para obtener su Client ID, para esto usan esta página: https://api.imgur.com/oauth2/addclient 
Al registrar, le colocan un nombre (cualquiera) y muy importante! seleccionan la segunda opción
![image](https://github.com/user-attachments/assets/7efb2597-d2aa-470b-bea5-1c1aa59fbbfd)
Luego, hasta abajo de la página dan clic en el botón "submit" y los llevará a una página con su ClientID el cual lo tienen que poner en el código del proyecto en esta parte:
![image](https://github.com/user-attachments/assets/152f6461-b307-41f9-8030-68d6470e4c9b)
(linea 73)
y listo!

